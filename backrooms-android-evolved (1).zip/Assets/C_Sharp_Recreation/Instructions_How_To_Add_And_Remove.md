# MIGRATION & INTEGRATION GUIDE (C# / UNITY)

This guide documents how to integrate the updated, high-fidelity **C# Recreation** files into your Unity project to mirror the atmospheric look, feel, and logic of our Jetpack Compose-based UI.

---

## 1. WHAT TO REMOVE & SCRIPTS TO REPLACE

To clean up your older architecture and ensure there are no namespace conflicts or duplicate code behaviors, complete the following removals in your older asset files:

### 🗑️ Remove/Clean and Replace:
1. **Old Main Menu scripts**: Remove old placeholder versions of `MainMenuController.cs` or custom scripts in `/Assets/Scripts/UI/` that don't have the fully modeled screen panels.
2. **Duplicate Save Logic**: Remove any custom save managers that don't serialize state through unified PlayerPrefs JSON.
3. **Placeholder Level Arrays**: Replace manual string parsing for level grids with the clean, modular `GameLevels.cs` model provided here.

---

## 2. INCLUDED C# SCRIPTS REFERENCE

Place the following scripts inside your Unity Project's `Assets/Scripts/` folder structure:

*   **`MainMenuController.cs`**: Handles UI animation glitches, volume sliders, look sensitivity, custom level selector buttons, user slots locks, credits layout connections, and feedback telemetry inputs.
*   **`GameLevels.cs`**: High-fidelity data structures storing layout grids, dull plaster colors, ambient fog values, spawn parameters, and hum sound frequencies for:
    *   *Level 0*: "The Lobby" (Classic Yellow damp maze)
    *   *Level 1*: "Pipe Dreams" ( Rusty steel industrial corridors)
    *   *Level 2*: "Habitable Zone" (Severe dark office structures)
*   **`UnitySaveManager.cs`**: State engine saving `maxUnlockedLevel`, `lookSensitivity`, and difficulties across sessions.
*   **`PlayerMovement.cs`**: Responsive character controls supporting PC mouse-look, Shift-sprints, and mobile touch joysticks.
*   **`SanityManager.cs`**: Computes creep-closeness entity drains and transforms it into visual post-process/VHS scanline distortion percentages.

---

## 3. HOW TO SET UP THE 5 UI PANELS IN UNITY

The `MainMenuController.cs` manages five distinct interfaces inside a single Unity Canvas. Set up your **Canvas Hierarchy** like this to get a perfect match:

```text
Canvas (Screen Space - Overlay)
 ├── BackgroundImage (Displays R.drawable.img_backrooms_bg snapshot)
 ├── ScanlineOverlay (Tiled low-opacity dark/yellow overlay image)
 ├── HeaderPanel (Top Centered)
 │    ├── TitleText (Raw Yellow - Animated Glitching text "DESOLATION:")
 │    ├── SubtitleText (Muted Straw Yellow "THE BACKROOMS")
 │    └── PanelIndicatorText (Faint label detailing the current menu state e.g., "SAVES")
 └── PanelsContainer
      ├── 1. MainMenuPanel (Active by default)
      │    ├── PlayOptionButton (Underlined layout)
      │    ├── SettingsOptionButton (Underlined layout)
      │    ├── CreditsOptionButton (Underlined layout)
      │    └── BottomRightFeedbackButton
      ├── 2. SavesPanel 
      │    ├── CardRow (Horizontal arrangement slot cards)
      │    │    ├── SlotButton_1 (Save 1, Level 0, Card Snapshot backdrop)
      │    │    ├── SlotButton_2 (Save 2, Level 1, Lock Overlay)
      │    │    └── SlotButton_3 (Save 3, Level 2, Lock Overlay)
      │    └── BackButton (Centered bottom)
      ├── 3. SettingsPanel
      │    ├── ScrollView_SettingsCapsules
      │    │    ├── MasterVolume (Slider capsule)
      │    │    ├── MusicVolume (Slider capsule)
      │    │    ├── SFXVolume (Slider capsule)
      │    │    ├── Brightness (Slider capsule)
      │    │    ├── Sensitivity (Slider capsule)
      │    │    └── GraphicsRow (LOW, MEDIUM, HIGH Button Capsules)
      │    └── BackButton
      ├── 4. CreditsPanel
      │    ├── BoxContainer (Dark outline frame)
      │    │    ├── CreditRow_1 (Role <--- Central Orb Dot ---> Name)
      │    │    └── CreditRow_2 ...
      │    └── BackButton
      └── 5. FeedbackPanel
           ├── FormContainer
           │    ├── YourFeedbackInputField (Multi-line text box)
           │    ├── EmailInputField (Single line email box)
           │    ├── IssueTypeDropdown (BUG, SUGGESTION, COMPLAINT, OTHER)
           │    └── TelemetryStatusText (Green response readouts: "📡 CONNECTING TO ANALOG...")
           └── ButtonsRow
                ├── SendButton
                └── BackButton
```

---

## 4. DESIGNING THE VISUAL ELEMENTS

To duplicate the aesthetic exactly:

### 🎨 Color Palette (Use Hex in Unity Inspector)
*   **Primary Golden Orange Text**: `#E5B842`
*   **Bright Yellow Highlights**: `#FFF092`
*   **Subtle White Glows**: `#FFF7C2`
*   **Dark Screen Panels Backing**: `#0A0905D9` (with $85\%$ Alpha blending)
*   **Vignette Contrast Tone**: `#020201AA`

### 👁️ CRT Scanlines
Create a UI Image with a tiling texture of vertical/horizontal thin dark lines. Set its blending color opacity to **`5%` alpha** and lay it on top of the whole background image to replicate a vintage analog surveillance feed.

### 🔌 Graphical Orbs for Credits
Design a sprite template with two fading line parts meeting a central solid point. Use this to separate roles and names on the credits page to give an eerie "wiring blueprint" theme.

---

## 5. BINDING COMPONENT DRAG-AND-DROPS

Select the GameObject holding your **`MainMenuController`**:
1. Drag the respective Panel parent folders into **`mainPanelRoot`**, **`savesPanelRoot`**, etc.
2. Drag the **TitleText** and **PanelIndicatorText** into their designated header slots.
3. Link the **3 Save Slot Buttons** into the `saveSlots` array, and their corresponding lock overlay groups (e.g., chains or dark locks) into `saveLockOverlays`.
4. Set Up the settings curves: link your volumetric sliders to **`masterVolumeSlider`**, **`musicVolumeSlider`**, and **`sfxVolumeSlider`**.
5. Connect your graphics Buttons to the **`graphicsButtons`** array list. Highlighting and outlines update dynamically.
6. For feedback forms: attach the text field elements into **`feedbackInput`**, dropdowns into **`issueTypeDropdown`**, and telemetry text to the green **`telTransmissionStatusText`** slot.

---

## 6. SCRIPT EVENT TRIGGERS

Configure standard Unity Buttons in the Inspector's `On Click()` event handlers to invoke these controller routines:

*   **Play button** $\rightarrow$ `MainMenuController.BtnPlay()`
*   **Settings button** $\rightarrow$ `MainMenuController.BtnSettings()`
*   **Credits button** $\rightarrow$ `MainMenuController.BtnCredits()`
*   **Feedback button** $\rightarrow$ `MainMenuController.BtnFeedback()`
*   **General BACK buttons** $\rightarrow$ `MainMenuController.BtnBackToMain()`
*   **Save Card Slot 1** $\rightarrow$ `MainMenuController.SelectSaveSlot(0)`
*   **Save Card Slot 2** $\rightarrow$ `MainMenuController.SelectSaveSlot(1)`
*   **Save Card Slot 3** $\rightarrow$ `MainMenuController.SelectSaveSlot(2)`
*   **Graphics LOW Button** $\rightarrow$ `MainMenuController.UpdateGraphicsSelection(0)`
*   **Graphics MEDIUM Button** $\rightarrow$ `MainMenuController.UpdateGraphicsSelection(1)`
*   **Graphics HIGH Button** $\rightarrow$ `MainMenuController.UpdateGraphicsSelection(2)`
*   **Feedback SEND Button** $\rightarrow$ `MainMenuController.SendFeedback()`

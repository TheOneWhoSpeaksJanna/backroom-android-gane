using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Desolation.Data;

namespace Desolation.UI
{
    public class MainMenuController : MonoBehaviour
    {
        public enum MenuPanel
        {
            Main,
            Saves,
            Settings,
            Credits,
            Feedback
        }

        [Header("Eerie Liminal Title Elements")]
        [SerializeField] private Text titleText;
        [SerializeField] private Text subtitleText;
        [SerializeField] private Text panelIndicatorText;
        [Range(0.1f, 5.0f)] [SerializeField] private float glanceGlitchMultiplier = 1.2f;

        [Header("Menu Screen Panels")]
        [SerializeField] private GameObject mainPanelRoot;
        [SerializeField] private GameObject savesPanelRoot;
        [SerializeField] private GameObject settingsPanelRoot;
        [SerializeField] private GameObject creditsPanelRoot;
        [SerializeField] private GameObject feedbackPanelRoot;

        [Header("Saves Screen Inputs")]
        [SerializeField] private GameObject[] saveSlots; // 3 Slots
        [SerializeField] private Text[] saveSlotLabels;
        [SerializeField] private Text[] saveSlotMetadata;
        [SerializeField] private GameObject[] saveLockOverlays;

        [Header("Settings Screen Controls")]
        [SerializeField] private Slider masterVolumeSlider;
        [SerializeField] private Slider musicVolumeSlider;
        [SerializeField] private Slider sfxVolumeSlider;
        [SerializeField] private Slider brightnessSlider;
        [SerializeField] private Slider sensitivitySlider;
        [SerializeField] private Button[] graphicsButtons; // Low, Medium, High button capsules

        [Header("Feedback Panel Controls")]
        [SerializeField] private InputField feedbackInput;
        [SerializeField] private InputField emailInput;
        [SerializeField] private Dropdown issueTypeDropdown;
        [SerializeField] private Text telTransmissionStatusText;
        [SerializeField] private Button feedbackSendButton;

        private GameStateData currentData;
        private MenuPanel activePanel = MenuPanel.Main;

        // Dynamic local settings variables
        private float tempMasterVolume = 0.85f;
        private float tempMusicVolume = 0.60f;
        private float tempSfxVolume = 0.70f;
        private float tempBrightness = 1.0f;
        private int tempGraphicsQuality = 2; // Default High

        private void Start()
        {
            // Consistent refresh pacing for liminal analog simulations
            Application.targetFrameRate = 60;

            LoadAndInitializeData();
            SwitchPanel(MenuPanel.Main);
        }

        private void Update()
        {
            ApplyVisualGlitchAnimations();
        }

        private void LoadAndInitializeData()
        {
            currentData = UnitySaveManager.LoadProgress();

            // Populate settings UI states
            if (sensitivitySlider != null)
            {
                sensitivitySlider.minValue = 0.5f;
                sensitivitySlider.maxValue = 2.5f;
                sensitivitySlider.value = currentData.lookSensitivity;
                sensitivitySlider.onValueChanged.AddListener(OnSensitivityChanged);
            }

            if (masterVolumeSlider != null)
            {
                masterVolumeSlider.value = tempMasterVolume;
                masterVolumeSlider.onValueChanged.AddListener((v) => tempMasterVolume = v);
            }

            if (musicVolumeSlider != null)
            {
                musicVolumeSlider.value = tempMusicVolume;
                musicVolumeSlider.onValueChanged.AddListener((v) => tempMusicVolume = v);
            }

            if (sfxVolumeSlider != null)
            {
                sfxVolumeSlider.value = tempSfxVolume;
                sfxVolumeSlider.onValueChanged.AddListener((v) => tempSfxVolume = v);
            }

            if (brightnessSlider != null)
            {
                brightnessSlider.value = tempBrightness;
                brightnessSlider.onValueChanged.AddListener((v) => tempBrightness = v);
            }

            // Set default graphics active visual elements
            UpdateGraphicsSelectionUI();

            // Populate level unlocks inside Save Slots cards exactly
            RefreshSavesPanelUI();

            if (telTransmissionStatusText != null)
            {
                telTransmissionStatusText.text = "";
            }
        }

        private void SwitchPanel(MenuPanel nextPanel)
        {
            activePanel = nextPanel;

            // Toggle panels activity
            if (mainPanelRoot != null) mainPanelRoot.SetActive(nextPanel == MenuPanel.Main);
            if (savesPanelRoot != null) savesPanelRoot.SetActive(nextPanel == MenuPanel.Saves);
            if (settingsPanelRoot != null) settingsPanelRoot.SetActive(nextPanel == MenuPanel.Settings);
            if (creditsPanelRoot != null) creditsPanelRoot.SetActive(nextPanel == MenuPanel.Credits);
            if (feedbackPanelRoot != null) feedbackPanelRoot.SetActive(nextPanel == MenuPanel.Feedback);

            // Update title visual metadata tag
            if (panelIndicatorText != null)
            {
                switch (nextPanel)
                {
                    case MenuPanel.Main:
                        panelIndicatorText.text = "";
                        break;
                    case MenuPanel.Saves:
                        panelIndicatorText.text = "SAVES";
                        break;
                    case MenuPanel.Settings:
                        panelIndicatorText.text = "SETTINGS";
                        break;
                    case MenuPanel.Credits:
                        panelIndicatorText.text = "CREDITS";
                        break;
                    case MenuPanel.Feedback:
                        panelIndicatorText.text = "FEEDBACK";
                        break;
                }
            }
        }

        private void RefreshSavesPanelUI()
        {
            for (int i = 0; i < 3; i++)
            {
                bool isUnlocked = i <= currentData.maxUnlockedLevel;

                if (i < saveSlots.Length && saveSlots[i] != null)
                {
                    // If unlocked, color card outline golden and allow triggers.
                    Button slotBtn = saveSlots[i].GetComponent<Button>();
                    if (slotBtn != null)
                    {
                        slotBtn.interactable = true; // allow click but display lock if not unlocked
                    }
                }

                if (i < saveLockOverlays.Length && saveLockOverlays[i] != null)
                {
                    saveLockOverlays[i].SetActive(!isUnlocked);
                }

                if (i < saveSlotLabels.Length && saveSlotLabels[i] != null)
                {
                    saveSlotLabels[i].text = "SAVE " + (i + 1);
                }

                if (i < saveSlotMetadata.Length && saveSlotMetadata[i] != null)
                {
                    string levelLvl = (i == 0) ? "Level 1" : (i == 1) ? "Level 2" : "Level 3";
                    saveSlotMetadata[i].text = isUnlocked ? "Backrooms\n" + levelLvl : "CORRUPTED\n[ENCRYPTED]";
                }
            }
        }

        // --- BUTTON TRIGGER METHODS ---
        public void BtnPlay() => SwitchPanel(MenuPanel.Saves);
        public void BtnSettings() => SwitchPanel(MenuPanel.Settings);
        public void BtnCredits() => SwitchPanel(MenuPanel.Credits);
        public void BtnFeedback() => SwitchPanel(MenuPanel.Feedback);
        public void BtnBackToMain() => SwitchPanel(MenuPanel.Main);

        public void SelectSaveSlot(int slotIndex)
        {
            bool isUnlocked = slotIndex <= currentData.maxUnlockedLevel;
            if (!isUnlocked)
            {
                Debug.LogWarning("[MainMenu] Trying to access a locked save data coordinate!");
                return;
            }

            // Save variables parameters into temporary player preferences for gameplay scenario loading references
            PlayerPrefs.SetInt("Active_LevelIndex", slotIndex);
            PlayerPrefs.SetInt("Settings_Difficulty", currentData.currentDifficulty);
            PlayerPrefs.SetFloat("Settings_Sensitivity", currentData.lookSensitivity);
            PlayerPrefs.SetFloat("Settings_MasterVolume", tempMasterVolume);
            PlayerPrefs.SetFloat("Settings_MusicVolume", tempMusicVolume);
            PlayerPrefs.SetFloat("Settings_SFXVolume", tempSfxVolume);
            PlayerPrefs.SetFloat("Settings_Brightness", tempBrightness);
            PlayerPrefs.SetInt("Settings_GraphicsQuality", tempGraphicsQuality);
            PlayerPrefs.Save();

            // Load primary scene
            UnityEngine.SceneManagement.SceneManager.LoadScene("GameplayScene");
        }

        public void UpdateGraphicsSelection(int qualityIndex)
        {
            tempGraphicsQuality = qualityIndex;
            UpdateGraphicsSelectionUI();
        }

        private void UpdateGraphicsSelectionUI()
        {
            if (graphicsButtons == null) return;
            for (int i = 0; i < graphicsButtons.Length; i++)
            {
                if (graphicsButtons[i] == null) continue;
                Image img = graphicsButtons[i].GetComponent<Image>();
                if (img != null)
                {
                    // Highlight selected Capsule
                    img.color = (i == tempGraphicsQuality) ? new Color(0.9f, 0.72f, 0.26f, 0.24f) : new Color(0f, 0f, 0f, 0.6f);
                }
            }
        }

        public void SendFeedback()
        {
            if (feedbackInput == null || telTransmissionStatusText == null) return;

            string content = feedbackInput.text.Trim();
            if (string.IsNullOrEmpty(content))
            {
                telTransmissionStatusText.color = new Color(0.9f, 0.3f, 0.3f, 1f);
                telTransmissionStatusText.text = "⚠️ RECORD CORRUPTED: TEXT BODY CANNOT BE EMPTY";
                return;
            }

            string email = (emailInput != null) ? emailInput.text : "";
            string type = (issueTypeDropdown != null) ? issueTypeDropdown.options[issueTypeDropdown.value].text : "BUG";

            // Simulated feedback storage submission telemetry trigger
            Debug.Log($"[FEEDBACK TRANSMISSION] Issue: {type} | Email: {email} | Text: {content}");

            telTransmissionStatusText.color = new Color(0.5f, 0.78f, 0.52f, 1f);
            telTransmissionStatusText.text = "📡 CONNECTING TO ANALOG SUITE... SUBMITTED!";

            feedbackInput.text = "";
            if (emailInput != null) emailInput.text = "";
        }

        private void OnSensitivityChanged(float val)
        {
            currentData.lookSensitivity = val;
            UnitySaveManager.SaveProgress(currentData);
        }

        private void ApplyVisualGlitchAnimations()
        {
            // Recreates the vintage neon underlay shift title pulsing of DESOLATION: THE BACKROOMS
            if (titleText != null)
            {
                float seed = Time.time * 6f;
                float driftX = Mathf.Sin(seed) * glanceGlitchMultiplier;
                // Animate glowing orange text colors slowly using cosine wave
                float glowAlpha = 0.65f + Mathf.Cos(Time.time * 2.5f) * 0.35f;

                titleText.color = new Color(0.9f, 0.72f, 0.26f, glowAlpha);
            }
        }
    }
}

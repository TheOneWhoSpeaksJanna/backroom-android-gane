package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.data.GameSaveManager
import com.example.game.GameState
import com.example.game.RaycasterEngine
import com.example.ui.GameScreen
import com.example.ui.MainMenuScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Immersive hardware system bar styling
        enableEdgeToEdge()
        
        // Instantiate our state managers
        val saveManager = GameSaveManager(applicationContext)
        val engine = RaycasterEngine()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black // Consistent horror dark backdrop
                ) {
                    var isPlaying by remember { mutableStateOf(false) }

                    if (isPlaying) {
                        GameScreen(
                            engine = engine,
                            saveManager = saveManager,
                            onExitToMenu = {
                                isPlaying = false
                            }
                        )
                    } else {
                        MainMenuScreen(
                            saveManager = saveManager,
                            onStartGame = { levelIndex, difficulty, sensitivity ->
                                engine.startLevel(levelIndex, difficulty, sensitivity)
                                isPlaying = true
                            }
                        )
                    }
                }
            }
        }
    }
}

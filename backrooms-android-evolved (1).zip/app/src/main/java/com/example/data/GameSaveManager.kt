package com.example.data

import android.content.Context
import android.content.SharedPreferences

class GameSaveManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("backrooms_save_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_UNLOCKED_LEVEL = "key_unlocked_level"
        private const val KEY_SENSITIVITY = "key_sensitivity"
        private const val KEY_SOUND_ENABLED = "key_sound_enabled"
        private const val KEY_HIGH_SCORE_PREFIX = "key_high_score_lvl_"
        private const val KEY_DIFFICULTY = "key_difficulty"
    }

    // Unlocked levels: 0 (Level 0), 1 (Level 1), 2 (Level 2)
    fun getMaxUnlockedLevel(): Int {
        return prefs.getInt(KEY_UNLOCKED_LEVEL, 0)
    }

    fun unlockLevel(level: Int) {
        val currentMax = getMaxUnlockedLevel()
        if (level > currentMax) {
            prefs.edit().putInt(KEY_UNLOCKED_LEVEL, level).apply()
        }
    }

    fun resetProgress() {
        prefs.edit()
            .putInt(KEY_UNLOCKED_LEVEL, 0)
            .putFloat(KEY_SENSITIVITY, 1.0f)
            .putBoolean(KEY_SOUND_ENABLED, true)
            .putInt(KEY_DIFFICULTY, 1) // 0 = Easy, 1 = Med, 2 = Hard
            .apply()
        // Reset high scores
        for (i in 0..2) {
            prefs.edit().putLong(KEY_HIGH_SCORE_PREFIX + i, 0L).apply()
        }
    }

    // Look sensitivity multiplier (0.5 to 2.5)
    fun getSensitivity(): Float {
        return prefs.getFloat(KEY_SENSITIVITY, 1.0f)
    }

    fun setSensitivity(sensitivity: Float) {
        prefs.edit().putFloat(KEY_SENSITIVITY, sensitivity).apply()
    }

    // Ambient sound option
    fun isSoundEnabled(): Boolean {
        return prefs.getBoolean(KEY_SOUND_ENABLED, true)
    }

    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()
    }

    // Game Difficulty (0 = Easy, 1 = Medium, 2 = Hard)
    fun getDifficulty(): Int {
        return prefs.getInt(KEY_DIFFICULTY, 1)
    }

    fun setDifficulty(difficulty: Int) {
        prefs.edit().putInt(KEY_DIFFICULTY, difficulty).apply()
    }

    // High score (seconds survived or time taken to escape)
    fun getHighScore(level: Int): Long {
        return prefs.getLong(KEY_HIGH_SCORE_PREFIX + level, 0L)
    }

    fun saveHighScore(level: Int, score: Long) {
        val currentHigh = getHighScore(level)
        // For survival time, higher is better
        if (score > currentHigh) {
            prefs.edit().putLong(KEY_HIGH_SCORE_PREFIX + level, score).apply()
        }
    }
}

package com.example.game

import androidx.compose.ui.graphics.Color

data class LevelData(
    val id: Int,
    val name: String,
    val description: String,
    val grid: List<String>,
    val spawnX: Float,
    val spawnY: Float,
    val wallColor: Color,
    val wallShadowColor: Color,
    val floorColor: Color,
    val ceilingColor: Color,
    val floorAmbientIntensity: Float, // ambient light baseline
    val ambientHumFrequency: Float // sound effect feedback
)

object GameLevels {
    val levels = listOf(
        // Level 0: Classic Yellow Carpets and Wallpaper
        LevelData(
            id = 0,
            name = "Level 0: The Lobby",
            description = "An endless maze of yellow plaster walls, damp carpets, and buzzing fluorescent hum.",
            grid = listOf(
                "1111111111111111",
                "1000001000000001",
                "1011101011111101",
                "1010001010000101",
                "1010111010110101",
                "1000100000110001",
                "1110111110111101",
                "1000000010000101",
                "1011111011110101",
                "1010001000010001",
                "1010101111011101",
                "1000101001000101",
                "1111101001110101",
                "1000001000010101",
                "1011111111000001", // Exit door positioned here
                "1111111111111111"
            ),
            spawnX = 1.5f,
            spawnY = 1.5f,
            wallColor = Color(0xFFD6C173), // Dull Mustard plaster
            wallShadowColor = Color(0xFF9E8E53), // Shadowed Mustard
            floorColor = Color(0xFF4C4222), // Wet brownish carpet
            ceilingColor = Color(0xFFC0BEB3), // Off-white office panels
            floorAmbientIntensity = 0.55f,
            ambientHumFrequency = 120f
        ),

        // Level 1: Pipe Dreams - Industrial Metallic Tunnels
        LevelData(
            id = 1,
            name = "Level 1: Pipe Dreams",
            description = "Dark concrete corridors surrounded by metal pipes, rust, dripping steam, and puddles.",
            grid = listOf(
                "1111111111111111",
                "1000100000000001",
                "1010101111110111",
                "1010001000010001",
                "1011101011011101",
                "1000100011000101",
                "1110111011110101",
                "1000001000010001",
                "1011101111011101",
                "1010100001000101",
                "1010111101110101",
                "1000000100010001",
                "1111110111011101",
                "1000010001010001",
                "1011000000000021", // 2 represents Exit Hatch
                "1111111111111111"
            ),
            spawnX = 1.5f,
            spawnY = 1.5f,
            wallColor = Color(0xFF5E6468), // Rusty Steel Iron Gray
            wallShadowColor = Color(0xFF3F4346), // Shadowed steel
            floorColor = Color(0xFF1F2224), // Damp slate-grey concrete
            ceilingColor = Color(0xFF2B2E31), // Heavy industrial ceiling piping
            floorAmbientIntensity = 0.38f,
            ambientHumFrequency = 80f
        ),

        // Level 2: The Habitable Zone - Grim dark office structures
        LevelData(
            id = 2,
            name = "Level 2: Habitable Zone",
            description = "A labyrinth of cold, dark office basement corridors with severe flickering lights.",
            grid = listOf(
                "1111111111111111",
                "1000000100000001",
                "1011110101111101",
                "1010010001000101",
                "1010011111010101",
                "1000000000010001",
                "1111110111111011",
                "1000010100000001",
                "1011010101111101",
                "1010010001000001",
                "1011111011111101",
                "1000001010000101",
                "1110101010110101",
                "1000100000110001",
                "1011111111111021", // Exit elevator threshold
                "1111111111111111"
            ),
            spawnX = 1.5f,
            spawnY = 1.5f,
            wallColor = Color(0xFF3B3B3D), // Extreme Dark Iron-Grey pillars
            wallShadowColor = Color(0xFF1E1E1F), // Dark pitch shadows
            floorColor = Color(0xFF141415), // Deep Charcoal
            ceilingColor = Color(0xFF1C1C1D), // Obsidian ceiling panels
            floorAmbientIntensity = 0.25f, // Pitch dark without flashlight!
            ambientHumFrequency = 50f
        )
    )
}

package com.example.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import java.util.Random
import kotlin.math.*

data class RayHit(
    val index: Int,
    val wallHeightFraction: Float, // Fraction of screen height (0.0 to 1.0)
    val shade: Float, // Ambient lighting shade (0.0 to 1.0)
    val isExit: Boolean,
    val isVerticalHit: Boolean, // True if hit a vertical grid boundary, useful for texture shadowing
    val depth: Float // Actual ray distance
)

enum class GameState {
    MENU,
    PLAYING,
    JUMPSCARE,
    GAMEOVER,
    VICTORY
}

enum class ItemType {
    BATTERY,
    ALMOND_WATER
}

data class GameItem(
    val id: Int,
    val type: ItemType,
    val x: Float,
    val y: Float,
    var isCollected: Boolean = false
)

class RaycasterEngine {
    // Player Configuration & Dynamic State
    var playerX by mutableStateOf(1.5f)
    var playerY by mutableStateOf(1.5f)
    var playerAngle by mutableStateOf(0f) // Radians
    
    var playerSanity by mutableStateOf(100f) // 0 to 100
    var batteryPercent by mutableStateOf(100f) // 0 to 100
    var stamina by mutableStateOf(100f) // 0 to 100
    var almondWaterCount by mutableStateOf(0)
    
    var currentLevelIndex by mutableStateOf(0)
    var currentLevelData: LevelData = GameLevels.levels[0]
    
    var isFlashlightOn by mutableStateOf(true)
    var state by mutableStateOf(GameState.MENU)
    
    // Entity States
    var entityX by mutableStateOf(8.5f)
    var entityY by mutableStateOf(8.5f)
    var isEntityChasing by mutableStateOf(false)
    var distanceToEntity by mutableStateOf(999f)
    
    // Items
    var itemsList = mutableListOf<GameItem>()
    var nearItem by mutableStateOf<GameItem?>(null)
    
    // Game settings
    var difficultyLevel = 1 // 0 = Easy, 1 = Med, 2 = Hard
    var lookSensitivity = 1.0f
    
    // Static / Render Constants
    val FOV = PI.toFloat() / 3f // 60 degrees Field Of View
    val NUM_RAYS = 120 // Rendering columns for smooth Compose Canvas draw
    val COLLISION_RADIUS = 0.22f // Smooth slider boundary

    private val random = Random()

    fun startLevel(levelIndex: Int, difficulty: Int, sensitivity: Float) {
        currentLevelIndex = levelIndex
        currentLevelData = GameLevels.levels[levelIndex]
        difficultyLevel = difficulty
        lookSensitivity = sensitivity
        
        // Setup spawn location from LevelData
        playerX = currentLevelData.spawnX
        playerY = currentLevelData.spawnY
        playerAngle = 0f
        
        // Reset vital stats
        playerSanity = 100f
        batteryPercent = 100f
        stamina = 100f
        almondWaterCount = 0
        isFlashlightOn = true
        state = GameState.PLAYING
        
        // Generate Level Pickups (Spawn in random empty cells)
        itemsList.clear()
        nearItem = null
        spawnItems()

        // Place the creepy Entity far away from player
        spawnEntity()
    }

    private fun spawnItems() {
        var itemId = 0
        val grid = currentLevelData.grid
        for (r in grid.indices) {
            for (c in grid[r].indices) {
                if (grid[r][c] == '0') {
                    // Check distance from spawn
                    val dX = c + 0.5f - playerX
                    val dY = r + 0.5f - playerY
                    val dist = sqrt(dX * dX + dY * dY)
                    // Spawn items 4+ tiles away with some density
                    if (dist > 4f && random.nextFloat() < 0.12f) {
                        val type = if (random.nextBoolean()) ItemType.BATTERY else ItemType.ALMOND_WATER
                        itemsList.add(GameItem(id = itemId++, type = type, x = c + 0.5f, y = r + 0.5f))
                    }
                }
            }
        }
    }

    private fun spawnEntity() {
        val grid = currentLevelData.grid
        var bestX = 8.5f
        var bestY = 8.5f
        var maxDist = 0f
        
        // Find empty spot farthest from player
        for (r in grid.indices) {
            for (c in grid[r].indices) {
                if (grid[r][c] == '0' || grid[r][c] == '2') {
                    val dX = c + 0.5f - playerX
                    val dY = r + 0.5f - playerY
                    val d = dX * dX + dY * dY
                    if (d > maxDist) {
                        maxDist = d
                        bestX = c + 0.5f
                        bestY = r + 0.5f
                    }
                }
            }
        }
        entityX = bestX
        entityY = bestY
        isEntityChasing = false
    }

    // Classic Wall-sliding Movement Execution with collision mitigation - "improved player movement"
    fun movePlayer(forwardSpeed: Float, strafeSpeed: Float, rotationChange: Float, isSprinting: Boolean) {
        if (state != GameState.PLAYING) return

        // 1. Update gaze rotation angle cleanly (adjusted for look sensitivity)
        playerAngle += (rotationChange * 0.05f * lookSensitivity)
        
        // Dynamic angle wrap-around
        if (playerAngle < 0) playerAngle += (2 * PI).toFloat()
        if (playerAngle > 2 * PI) playerAngle -= (2 * PI).toFloat()

        // 2. Compute movement multiplier based on stamina/sprint
        var mSpeed = 0.065f // base movement speed
        if (isSprinting && stamina > 5f) {
            mSpeed *= 1.8f // Sprint boost factor
            stamina = (stamina - 0.75f).coerceAtLeast(0f)
        } else {
            stamina = (stamina + 0.35f).coerceIn(0f, 100f)
        }

        // Apply forward/backward vector calculations
        val dxVec = cos(playerAngle) * forwardSpeed - sin(playerAngle) * strafeSpeed
        val dyVec = sin(playerAngle) * forwardSpeed + cos(playerAngle) * strafeSpeed
        
        val targetDx = dxVec * mSpeed
        val targetDy = dyVec * mSpeed

        // 3. Wall Sliding Collision Resolution (Slide instead of full block on grazing angles)
        val grid = currentLevelData.grid

        // X collision check
        val nextX = playerX + targetDx
        val safetyBufferX = if (targetDx > 0) COLLISION_RADIUS else -COLLISION_RADIUS
        val checkCellX = floor(nextX + safetyBufferX).toInt()
        val currentCellY = floor(playerY).toInt()

        if (isPassable(checkCellX, currentCellY)) {
            playerX = nextX
        }

        // Y collision check
        val nextY = playerY + targetDy
        val safetyBufferY = if (targetDy > 0) COLLISION_RADIUS else -COLLISION_RADIUS
        val checkCellY = floor(nextY + safetyBufferY).toInt()
        val currentCellX = floor(playerX).toInt()

        if (isPassable(currentCellX, checkCellY)) {
            playerY = nextY
        }

        // 4. Exits & Goal Accomplishment Detection
        val levelGridCell = grid[floor(playerY).toInt()][floor(playerX).toInt()]
        if (levelGridCell == '2' || levelGridCell == 'E') {
            // Next Level unlocked
            if (currentLevelIndex < GameLevels.levels.size - 1) {
                state = GameState.VICTORY
            } else {
                state = GameState.VICTORY // Universal win state for last level
            }
        }
    }

    private fun isPassable(gridX: Int, gridY: Int): Boolean {
        val grid = currentLevelData.grid
        if (gridY < 0 || gridY >= grid.size || gridX < 0 || gridX >= grid[0].length) return false
        val cellObj = grid[gridY][gridX]
        // Corridors ('0') or Exits ('2'/'E') are passable, walls ('1') are not.
        return cellObj == '0' || cellObj == '2' || cellObj == 'E'
    }

    // Continuous Frame Update: update battery, Sanity, AI hunting, flicker conditions
    fun updateTicks(deltaTimeMs: Long) {
        if (state != GameState.PLAYING) return

        // Backrooms are ambiently illuminated, no battery drain required
        batteryPercent = 100f

        // 2. Check Item collection range (automatic magnetic pickup)
        nearItem = null
        for (item in itemsList) {
            if (!item.isCollected) {
                val dX = item.x - playerX
                val dY = item.y - playerY
                val dist = sqrt(dX * dX + dY * dY)
                if (dist < 0.70f) {
                    collectItem(item)
                } else if (dist < 1.5f) {
                    nearItem = item
                }
            }
        }

        // 3. AI Entity Tracker & Hunting Algorithm
        val entityDeltaX = playerX - entityX
        val entityDeltaY = playerY - entityY
        distanceToEntity = sqrt(entityDeltaX * entityDeltaX + entityDeltaY * entityDeltaY)

        val speedMultiplier = when (difficultyLevel) {
            0 -> 0.015f // Easy patrolling speed
            1 -> 0.024f // Med
            2 -> 0.035f // Hard
            else -> 0.024f
        }

        // Raycast line of sight check
        val isPlayerVisible = hasLineOfSight(entityX, entityY, playerX, playerY)
        isEntityChasing = isPlayerVisible || (distanceToEntity < 5.0f)

        // Chase or Patrol
        if (isEntityChasing) {
            // Moves direction vector towards player
            val moveAngle = atan2(entityDeltaY, entityDeltaX)
            val eDx = cos(moveAngle) * speedMultiplier * 1.35f
            val eDy = sin(moveAngle) * speedMultiplier * 1.35f
            
            // Safe slide movements for entity to prevent getting stuck
            val nextEntX = entityX + eDx
            val nextEntY = entityY + eDy
            if (isPassable(floor(nextEntX).toInt(), floor(entityY).toInt())) entityX = nextEntX
            if (isPassable(floor(entityX).toInt(), floor(nextEntY).toInt())) entityY = nextEntY
        } else {
            // Idle jittery patrol towards player's general quadrant
            val randomFactorAngle = (random.nextFloat() * 2 * PI).toFloat()
            val eDx = cos(randomFactorAngle) * speedMultiplier * 0.4f
            val eDy = sin(randomFactorAngle) * speedMultiplier * 0.4f
            
            val nextEntX = entityX + eDx
            val nextEntY = entityY + eDy
            if (isPassable(floor(nextEntX).toInt(), floor(entityY).toInt())) entityX = nextEntX
            if (isPassable(floor(entityX).toInt(), floor(nextEntY).toInt())) entityY = nextEntY
        }

        // Sanity drains based on proximity & visibility
        if (distanceToEntity < 4.5f) {
            // Scale drain closer
            val proximityFactor = (5.0f - distanceToEntity).coerceIn(0f, 5f)
            val baseDrain = when (difficultyLevel) {
                0 -> 0.15f
                1 -> 0.28f
                2 -> 0.45f
                else -> 0.28f
            }
            playerSanity = (playerSanity - (proximityFactor * baseDrain)).coerceAtLeast(0f)
        } else {
            // Gradual recover sanity in safety! (max up to 80%)
            if (playerSanity < 80f) {
                playerSanity = (playerSanity + 0.03f).coerceAtMost(80f)
            }
        }

        // Trigger jumpscare if caught
        if (distanceToEntity < 0.45f) {
            state = GameState.JUMPSCARE
        }

        if (playerSanity <= 0f) {
            state = GameState.GAMEOVER
        }
    }

    private fun collectItem(item: GameItem) {
        item.isCollected = true
        if (item.type == ItemType.BATTERY) {
            // Battery works as an Energy Drink to instantly boost/restore sprinting stamina
            stamina = (stamina + 50f).coerceAtMost(100f)
        } else if (item.type == ItemType.ALMOND_WATER) {
            // Adds to almond bottles inventory instead of direct automatic consumption
            almondWaterCount++
        }
    }

    fun drinkAlmondWater() {
        if (almondWaterCount > 0) {
            almondWaterCount--
            playerSanity = (playerSanity + 35f).coerceAtMost(100f)
        }
    }

    // Bresenham or Step-by-step Raycast Line of Sight from A to B
    private fun hasLineOfSight(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val dx = x2 - x1
        val dy = y2 - y1
        val dist = sqrt(dx * dx + dy * dy)
        if (dist < 0.1f) return true

        val steps = (dist * 10).toInt().coerceAtLeast(2)
        for (i in 1 until steps) {
            val t = i.toFloat() / steps
            val checkX = x1 + dx * t
            val checkY = y1 + dy * t
            if (!isPassable(floor(checkX).toInt(), floor(checkY).toInt())) {
                return false
            }
        }
        return true
    }

    // Pure 3D Raycasting mathematical calculation layer for Canvas renderer
    fun performRaycasting(): List<RayHit> {
        val hits = ArrayList<RayHit>(NUM_RAYS)
        val grid = currentLevelData.grid
        val startAngle = playerAngle - (FOV / 2f)

        for (i in 0 until NUM_RAYS) {
            // Map column position fraction
            val fraction = i.toFloat() / (NUM_RAYS - 1)
            val rayAngle = startAngle + (fraction * FOV)

            val sinA = sin(rayAngle)
            val cosA = cos(rayAngle)

            // DDA (Digital Differential Analysis) Algorithm for fast, ultra-precise grid intersection
            // Step size for grid lines
            val deltaDistX = if (cosA == 0f) Float.MAX_VALUE else abs(1f / cosA)
            val deltaDistY = if (sinA == 0f) Float.MAX_VALUE else abs(1f / sinA)

            var mapX = floor(playerX).toInt()
            var mapY = floor(playerY).toInt()

            var sideDistX: Float
            var sideDistY: Float

            val stepX: Int
            val stepY: Int

            if (cosA < 0) {
                stepX = -1
                sideDistX = (playerX - mapX) * deltaDistX
            } else {
                stepX = 1
                sideDistX = (mapX + 1.0f - playerX) * deltaDistX
            }

            if (sinA < 0) {
                stepY = -1
                sideDistY = (playerY - mapY) * deltaDistY
            } else {
                stepY = 1
                sideDistY = (mapY + 1.0f - playerY) * deltaDistY
            }

            var hit = false
            var isVerticalHit = false
            var hitVal = '0'
            var side = 0 // 0 = NS grid hit, 1 = EW grid hit
            var maxSteps = 30 // Render distance boundary

            while (!hit && maxSteps > 0) {
                if (sideDistX < sideDistY) {
                    sideDistX += deltaDistX
                    mapX += stepX
                    side = 0
                } else {
                    sideDistY += deltaDistY
                    mapY += stepY
                    side = 1
                }

                // Check out of level bounds
                if (mapY < 0 || mapY >= grid.size || mapX < 0 || mapX >= grid[mapY].length) {
                    break
                }

                val cell = grid[mapY][mapX]
                if (cell == '1' || cell == '2' || cell == 'E') {
                    hit = true
                    isVerticalHit = (side == 0)
                    hitVal = cell
                }
                maxSteps--
            }

            // Calculate actual distance to grid wall
            val perpendicularDist = if (side == 0) {
                (mapX - playerX + (1 - stepX) / 2f) / cosA
            } else {
                (mapY - playerY + (1 - stepY) / 2f) / sinA
            }

            // Correct warp effect (fisheye warp)
            val correctedDist = perpendicularDist * cos(rayAngle - playerAngle)
            val safeDist = correctedDist.coerceAtLeast(0.1f)

            // Dynamic projection height (0.0 to 1.0) relative to screen
            // Height falls off based on distance
            val wallHeightFraction = (1.1f / safeDist).coerceIn(0f, 1f)

            // Lights & Ambiance Calculations: Uniform ambient fluorescent ceiling lighting representation with smooth linear depth fog range
            var shade = 1.0f / (1.0f + perpendicularDist * 0.12f) // Clean depth fog decay
            
            // Add level ambient baseline yellow/grey lighting
            shade += currentLevelData.floorAmbientIntensity

            // Severe backrooms ceiling light flicker simulation for Level 2 (Habitable Zone office structure)
            if (currentLevelIndex == 2) {
                val timeMilli = System.currentTimeMillis()
                val sinFlicker = sin(timeMilli * 0.005f) * cos(timeMilli * 0.013f)
                if (sinFlicker > 0.45f) {
                    shade *= 0.22f // Ceiling hum light dimming
                } else if (sinFlicker < -0.6f) {
                    shade *= 0.08f // Severe room-level office blackout flicker
                }
            }

            // Clamp final shading intensity
            val finalShade = shade.coerceIn(0.12f, 1.0f)
            val isExitSymbol = (hitVal == '2' || hitVal == 'E')

            hits.add(
                RayHit(
                    index = i,
                    wallHeightFraction = wallHeightFraction,
                    shade = finalShade,
                    isExit = isExitSymbol,
                    isVerticalHit = isVerticalHit,
                    depth = safeDist
                )
            )
        }
        return hits
    }
}

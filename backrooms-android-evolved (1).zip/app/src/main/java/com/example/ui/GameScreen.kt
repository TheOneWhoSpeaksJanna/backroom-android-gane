package com.example.ui

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameSaveManager
import com.example.game.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.delay
import java.util.Random
import kotlin.math.*

@Composable
fun GameScreen(
    engine: RaycasterEngine,
    saveManager: GameSaveManager,
    onExitToMenu: () -> Unit
) {
    val context = LocalContext.current
    val systemRandom = remember { Random() }

    // Touch controls input vectors
    var moveJoystickOffset by remember { mutableStateOf(Offset.Zero) }
    val maxJoystickDragRadius = 65f // Pixels limit for analog movement bounds

    // Input States
    var forwardMovementAmount by remember { mutableStateOf(0f) }
    var strafeMovementAmount by remember { mutableStateOf(0f) }
    var rotationAngleAmount by remember { mutableStateOf(0f) }
    var isSprinting by remember { mutableStateOf(false) }

    // Glitch oscillations for flicker and red static
    val infiniteTransition = rememberInfiniteTransition(label = "Static")
    val randomFlickerSeed by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(220, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "seed"
    )

    // Dynamic Timecode tracker (vintage lost footage camcorder style)
    val initialTimecode = remember { System.currentTimeMillis() }
    var timecodeStr by remember { mutableStateOf("00:00:00:00") }

    LaunchedEffect(engine.state) {
        while (isActive) {
            val elapsed = System.currentTimeMillis() - initialTimecode
            val frames = (elapsed % 1000 / 33).toInt() // roughly 30 fps
            val secs = (elapsed / 1000 % 60).toInt()
            val mins = (elapsed / 60000 % 60).toInt()
            val hrs = (elapsed / 3600000).toInt()
            timecodeStr = String.format("%02d:%02d:%02d:%01d%01d", hrs, mins, secs, frames / 10, frames % 10)
            delay(33)
        }
    }

    // Main 60FPS high-speed loop tracker
    LaunchedEffect(engine.state) {
        if (engine.state == GameState.PLAYING) {
            // Trigger periodic background drone sounds if enabled
            val toneGenerator = try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 45)
            } catch (e: Exception) {
                null
            }

            try {
                var lastTime = System.currentTimeMillis()
                while (isActive && engine.state == GameState.PLAYING) {
                    withFrameMillis { frameTime ->
                        val now = System.currentTimeMillis()
                        val dT = (now - lastTime).coerceIn(1L, 40L) // Safety cap
                        lastTime = now

                        // Handle joystick mapping
                        val dragFractionX = moveJoystickOffset.x / maxJoystickDragRadius
                        val dragFractionY = moveJoystickOffset.y / maxJoystickDragRadius
                        
                        forwardMovementAmount = -dragFractionY.coerceIn(-1.0f, 1.0f)
                        strafeMovementAmount = dragFractionX.coerceIn(-1.0f, 1.0f)

                        // Execute physics ticks inside Engine
                        engine.movePlayer(
                            forwardSpeed = forwardMovementAmount,
                            strafeSpeed = strafeMovementAmount,
                            rotationChange = rotationAngleAmount,
                            isSprinting = isSprinting
                        )

                        engine.updateTicks(dT)

                        // Decay rotational gaze change smoothly after touch release
                        rotationAngleAmount *= 0.65f // drag friction response

                        // Hum buzz generator trigger based on proximity
                        if (saveManager.isSoundEnabled() && toneGenerator != null && systemRandom.nextFloat() < 0.015f) {
                            val distanceToTarget = engine.distanceToEntity
                            val pulseFreq = if (distanceToTarget < 4f) {
                                ToneGenerator.TONE_PROP_BEEP2
                            } else {
                                ToneGenerator.TONE_PROP_BEEP
                            }
                            try {
                                toneGenerator.startTone(pulseFreq, 85)
                            } catch (e: Exception) {
                                // ignore silent errors
                            }
                        }
                    }
                }
            } finally {
                try {
                    toneGenerator?.release()
                } catch (e: Exception) {
                    // Ignore silent release exceptions
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (engine.state == GameState.PLAYING || engine.state == GameState.JUMPSCARE) {
            val levelData = engine.currentLevelData

            // Render view of 3D Raycast columns inside native Canvas (Widescreen HUD)
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            // Touch swipe on right side looks around (dual axis layout)
                            detectDragGestures(
                                onDragEnd = {
                                    rotationAngleAmount = 0.0f
                                },
                                onDragCancel = {
                                    rotationAngleAmount = 0.0f
                                }
                            ) { change, dragAmount ->
                                change.consume()
                                rotationAngleAmount = dragAmount.x * 0.16f
                            }
                        }
                ) {
                    val width = size.width
                    val height = size.height

                    val rayHits = engine.performRaycasting()
                    val colWidth = width / rayHits.size

                    // Render Columns (Ceiling, Floor, Walls)
                    for (i in rayHits.indices) {
                        val hit = rayHits[i]
                        val colHeight = height * hit.wallHeightFraction
                        val topY = (height - colHeight) / 2f
                        val bottomY = topY + colHeight

                        // Ambient flickering shade
                        var finalShade = hit.shade
                        
                        // Entity nearby static and flicker
                        if (engine.distanceToEntity < 3.5f && systemRandom.nextFloat() < 0.35f) {
                            finalShade *= (0.1f + systemRandom.nextFloat() * 0.4f)
                        }

                        // Ceiling gradient (Office fluorescent lighting backdrop)
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    levelData.ceilingColor.copy(alpha = 0.65f),
                                    Color.Black
                                )
                            ),
                            topLeft = Offset(i * colWidth, 0f),
                            size = Size(colWidth + 1f, topY)
                        )

                        // Floor gradient (Dirty office carpet / damp raw concrete tile backdrop)
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black,
                                    levelData.floorColor.copy(alpha = 0.75f)
                                )
                            ),
                            topLeft = Offset(i * colWidth, bottomY),
                            size = Size(colWidth + 1f, height - bottomY)
                        )

                        val wallBaseColor = if (hit.isExit) {
                            Color(0xFFE25454) // Exit Warn Red
                        } else {
                            levelData.wallColor
                        }

                        val sideDimMultiplier = if (hit.isVerticalHit) 0.82f else 1.0f
                        val wallColorShaded = Color(
                            red = (wallBaseColor.red * finalShade * sideDimMultiplier).coerceIn(0f, 1f),
                            green = (wallBaseColor.green * finalShade * sideDimMultiplier).coerceIn(0f, 1f),
                            blue = (wallBaseColor.blue * finalShade * sideDimMultiplier).coerceIn(0f, 1f),
                            alpha = 1.0f
                        )

                        drawRect(
                            color = wallColorShaded,
                            topLeft = Offset(i * colWidth, topY),
                            size = Size(colWidth + 1f, colHeight)
                        )
                    }

                    // --- 3D Sprites Projection layer ---

                    // 1. Hovering collectible Items (Almond Water / Batteries)
                    for (item in engine.itemsList) {
                        if (!item.isCollected) {
                            val itemDx = item.x - engine.playerX
                            val itemDy = item.y - engine.playerY
                            val itemDist = sqrt(itemDx * itemDx + itemDy * itemDy)
                            
                            var itemAngle = atan2(itemDy, itemDx) - engine.playerAngle
                            while (itemAngle < -PI) itemAngle += (2 * PI).toFloat()
                            while (itemAngle > PI) itemAngle -= (2 * PI).toFloat()
                            
                            // Check if item is inside player's FOV cone
                            if (abs(itemAngle) < 0.8f && itemDist > 0.1f) {
                                val sX = (width / 2f) + (tan(itemAngle) / tan(engine.FOV / 2f)) * (width / 2f)
                                val sSize = height * (0.35f / itemDist)
                                
                                val colIdx = (sX / colWidth).toInt().coerceIn(0, rayHits.size - 1)
                                if (itemDist < rayHits[colIdx].depth) {
                                    val bobbing = sin(System.currentTimeMillis() * 0.005f) * sSize * 0.15f
                                    val sTop = (height - sSize) / 2f + sSize * 0.8f + bobbing
                                    
                                    val itemColor = if (item.type == ItemType.ALMOND_WATER) Color(0xFF3EE2DF) else Color(0xFFFFD15B)
                                    
                                    // Draw glowing canister/capsule sprite representation
                                    drawRoundRect(
                                        color = itemColor.copy(alpha = (1.0f - (itemDist / 7f)).coerceIn(0.15f, 1.0f)),
                                        topLeft = Offset(sX - sSize * 0.12f, sTop),
                                        size = Size(sSize * 0.24f, sSize * 0.45f),
                                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                                    )
                                    // Drawing neon bubble background halo around item
                                    drawCircle(
                                        color = itemColor.copy(alpha = 0.2f * randomFlickerSeed),
                                        radius = sSize * 0.35f,
                                        center = Offset(sX, sTop + sSize * 0.22f)
                                    )
                                }
                            }
                        }
                    }

                    // 2. Projected Terrifying Wire-mesh "Bacteria" Stick Entity
                    val entDx = engine.entityX - engine.playerX
                    val entDy = engine.entityY - engine.playerY
                    val entDist = sqrt(entDx * entDx + entDy * entDy)

                    var entAngle = atan2(entDy, entDx) - engine.playerAngle
                    while (entAngle < -PI) entAngle += (2 * PI).toFloat()
                    while (entAngle > PI) entAngle -= (2 * PI).toFloat()

                    if (abs(entAngle) < 0.8f && entDist > 0.1f) {
                        val screenX = (width / 2f) + (tan(entAngle) / tan(engine.FOV / 2f)) * (width / 2f)
                        val eHeight = height * (1.1f / entDist)
                        val eWidth = eHeight * 0.5f

                        // Column visual occlusion test to hide behind solid walls
                        val colIdx = (screenX / colWidth).toInt().coerceIn(0, rayHits.size - 1)
                        if (entDist < rayHits[colIdx].depth) {
                            val cenX = screenX
                            val spriteTop = (height - eHeight) / 2f
                            
                            val figureAlpha = (1.0f - (entDist / 14f)).coerceIn(0.2f, 1.0f)
                            val entityColor = Color(0xFF131311).copy(alpha = figureAlpha)
                            
                            // Spine column
                            drawRect(
                                color = entityColor,
                                topLeft = Offset(cenX - eWidth * 0.05f, spriteTop + eHeight * 0.2f),
                                size = Size(eWidth * 0.10f, eHeight * 0.75f)
                            )
                            // Skeletal head
                            drawCircle(
                                color = entityColor,
                                radius = eWidth * 0.13f,
                                center = Offset(cenX, spriteTop + eHeight * 0.14f)
                            )
                            // Left spindly arm
                            drawLine(
                                color = entityColor,
                                start = Offset(cenX, spriteTop + eHeight * 0.3f),
                                end = Offset(cenX - eWidth * 0.42f, spriteTop + eHeight * 0.55f),
                                strokeWidth = eWidth * 0.04f
                            )
                            // Right spindly arm
                            drawLine(
                                color = entityColor,
                                start = Offset(cenX, spriteTop + eHeight * 0.35f),
                                end = Offset(cenX + eWidth * 0.45f, spriteTop + eHeight * 0.62f),
                                strokeWidth = eWidth * 0.04f
                            )
                            // Blinking pinprick warning eyes
                            if (randomFlickerSeed > 0.45f) {
                                drawCircle(
                                    color = Color(0xFFFF2222),
                                    radius = eWidth * 0.035f,
                                    center = Offset(cenX - eWidth * 0.05f, spriteTop + eHeight * 0.13f)
                                )
                                drawCircle(
                                    color = Color(0xFFFF2222),
                                    radius = eWidth * 0.035f,
                                    center = Offset(cenX + eWidth * 0.05f, spriteTop + eHeight * 0.13f)
                                )
                            }
                        }
                    }

                    // CRT / VHS Vignette
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)),
                            center = Offset(width / 2, height / 2),
                            radius = width * 0.78f
                        ),
                        center = Offset(width / 2, height / 2),
                        radius = width
                    )
                }

                // CRT / VHS high dynamic interference distortion when entity draws close!
                if (engine.distanceToEntity < 5.0f) {
                    val severity = ((5.0f - engine.distanceToEntity) / 4.5f).coerceIn(0f, 1f)
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height
                        
                        // Draw horizontal glitch tracking bars
                        val linesCount = (5 + 16 * severity).toInt()
                        for (l in 0 until linesCount) {
                            val bandH = systemRandom.nextFloat() * 45f * severity
                            val bandY = systemRandom.nextFloat() * height
                            drawRect(
                                color = Color(0xFFFFD15B).copy(alpha = 0.09f * severity * randomFlickerSeed),
                                topLeft = Offset(0f, bandY),
                                size = Size(width, bandH)
                            )
                        }

                        // Danger red blood halo mask around frame boundaries
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(Color.Transparent, Color(0xFFD32F2F).copy(alpha = 0.38f * severity * randomFlickerSeed)),
                                radius = width * 0.65f
                            )
                        )
                    }
                }
            }

            // --- JUMPSCARE TRIGGER VIEW ---
            if (engine.state == GameState.JUMPSCARE) {
                Box(
                    modifier = Modifier.fillMaxSize().background(Color(0xFF0F0E0E)),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawRect(
                            color = Color(0xFF6B1B1B).copy(alpha = 0.20f * randomFlickerSeed)
                        )
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "⚡ VHS SIGNAL OVERRIDE ⚡",
                            color = Color(0xFFCC3333),
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "⚫ LOG ERROR: DATA CORRUPTION ⚫",
                            color = Color.White.copy(alpha = randomFlickerSeed),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .height(5.dp)
                                .background(Color.Red.copy(alpha = randomFlickerSeed))
                        )
                    }

                    // Direct jump to gameover screen after playback completes
                    LaunchedEffect(Unit) {
                        delay(2300)
                        engine.state = GameState.GAMEOVER
                    }
                }
            }

            // --- CAMCORDER VHS BEAUTIFIED OVERLAYS ---
            if (engine.state == GameState.PLAYING) {
                Box(modifier = Modifier.fillMaxSize()) {
                    
                    // Top Bar Overlay (Timecode, REC indicator, Battery)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                            .statusBarsPadding()
                            .padding(horizontal = 24.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left Head: REC flashing + PLAY text
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                val isFlashOn = (System.currentTimeMillis() % 1000) > 500
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (isFlashOn) Color.Red else Color.Transparent)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "REC",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                            }
                            Text(
                                text = "PLAY ▶",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        // Middle Head: Diagnostic alerts / Exit goal hint
                        Text(
                            text = "PROXIMITY WARNING // FIND THRESHOLD",
                            color = if (engine.distanceToEntity < 4.0f) Color(0xFFFF4D4D) else Color(0xFFFFD15B).copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )

                        // Right Head: Timecode + Battery meter block
                        Column(
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = timecodeStr,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "LBY 00",
                                    color = Color(0xFFA5A5A4),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                // Battery frame outline
                                Box(
                                    modifier = Modifier
                                        .width(26.dp)
                                        .height(14.dp)
                                        .border(1.dp, Color.White, RoundedCornerShape(2.dp))
                                        .padding(1.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .fillMaxWidth(0.9f)
                                            .background(Color.White)
                                    )
                                }
                            }
                        }
                    }

                    // Diagnostic Metrics Sidebar (Left Center) - Compact modern diagnostic overlays
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(horizontal = 24.dp)
                            .width(135.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Vitals: Sanity
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "SYS.SANITY: ${engine.playerSanity.toInt()}%",
                                color = if (engine.playerSanity > 30f) Color(0xFF3EE2DF) else Color(0xFFFF4D4D),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .border(1.dp, Color.White.copy(alpha = 0.2f))
                                    .background(Color.Black.copy(alpha = 0.6f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(engine.playerSanity / 100f)
                                        .background(if (engine.playerSanity > 30f) Color(0xFF3EE2DF) else Color(0xFFFF4D4D))
                                )
                            }
                        }

                        // Vitals: Stamina
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "SYS.STAMINA: ${engine.stamina.toInt()}%",
                                color = Color(0xFF81C784),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .border(1.dp, Color.White.copy(alpha = 0.2f))
                                    .background(Color.Black.copy(alpha = 0.6f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(engine.stamina / 100f)
                                        .background(Color(0xFF4CAF50))
                                )
                            }
                        }

                        // Diagnostic: Water stock badge count
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalDrink,
                                contentDescription = "Almond counter",
                                tint = Color(0xFFFFD15B),
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "ALMOND: ${engine.almondWaterCount}",
                                color = Color(0xFFFFD15B),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Radar Mini Map Scanner (Top Right Center, floating)
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 80.dp, end = 24.dp)
                            .size(76.dp)
                            .border(1.dp, Color(0xFFFFD15B).copy(alpha = 0.4f), CircleShape)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.7f))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val radius = size.width / 2f
                            val center = Offset(radius, radius)
                            
                            drawCircle(
                                color = Color(0xFFFFD15B).copy(alpha = 0.12f),
                                center = center,
                                radius = radius * 0.5f
                            )

                            // Radars Sweep beam rotation
                            val angle = (System.currentTimeMillis() % 2000 / 2000f) * 2 * PI
                            drawLine(
                                color = Color(0xFFFFD15B).copy(alpha = 0.35f),
                                start = center,
                                end = Offset(
                                    (radius + cos(angle) * radius).toFloat(),
                                    (radius + sin(angle) * radius).toFloat()
                                ),
                                strokeWidth = 1.5f
                            )

                            // Blinking Entity Red Dot
                            val scanDist = engine.distanceToEntity
                            if (scanDist < 6.5f) {
                                val dX = engine.entityX - engine.playerX
                                val dY = engine.entityY - engine.playerY
                                
                                val scale = radius / 6.0f
                                val mapDotX = radius + dX * scale
                                val mapDotY = radius + dY * scale
                                
                                val alphaPulse = abs(sin((System.currentTimeMillis() % 600) / 600f * 2 * PI))
                                drawCircle(
                                    color = Color.Red.copy(alpha = alphaPulse.toFloat()),
                                    radius = 4f,
                                    center = Offset(mapDotX, mapDotY)
                                )
                            }

                            // Player indicator marker dot
                            drawCircle(
                                color = Color(0xFF3EE2DF),
                                radius = 3f,
                                center = center
                            )
                        }
                    }

                    // Near item helper overlay popup in center
                    engine.nearItem?.let { item ->
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .offset(y = (-60).dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF33250F))
                                .border(1.dp, Color(0xFFFFC107), RoundedCornerShape(6.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (item.type == ItemType.BATTERY) {
                                    "⚡ AUTOMATIC STAMINA RECOVERY CHARGING..."
                                } else {
                                    "⚡ NEAR ALMOND WATER (WALK TO ACQUIRE)"
                                },
                                color = Color(0xFFFFD54F),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // --- ERGONOMIC BOTTOM TOUCH CONTROL PANELS (Landscape Optimized) ---
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(horizontal = 24.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        // Left Thumb Joystick Pad Controller
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                                .background(Color.Black.copy(alpha = 0.40f))
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { moveJoystickOffset = Offset.Zero },
                                        onDragEnd = { moveJoystickOffset = Offset.Zero },
                                        onDragCancel = { moveJoystickOffset = Offset.Zero }
                                    ) { change, dragAmount ->
                                        change.consume()
                                        val nextOffset = moveJoystickOffset + dragAmount
                                        val distance = sqrt(nextOffset.x * nextOffset.x + nextOffset.y * nextOffset.y)
                                        moveJoystickOffset = if (distance > maxJoystickDragRadius) {
                                            Offset(
                                                (nextOffset.x / distance) * maxJoystickDragRadius,
                                                (nextOffset.y / distance) * maxJoystickDragRadius
                                            )
                                        } else {
                                            nextOffset
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawCircle(
                                    color = Color.White.copy(alpha = 0.08f),
                                    radius = size.width / 4f
                                )
                            }
                            // Joystick center pad orb
                            Box(
                                modifier = Modifier
                                    .offset(
                                        x = (moveJoystickOffset.x / 2.2f).dp,
                                        y = (moveJoystickOffset.y / 2.2f).dp
                                    )
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color(0xFFEADB95), Color(0xFF947B3B))
                                        )
                                    )
                                    .border(1.5.dp, Color(0xFFFFC107).copy(alpha = 0.7f), CircleShape)
                            )
                        }

                        // Right Thumb Action Toggle row (Sprint, Almond Water drink, Leave)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Sprint button gauge
                            IconButton(
                                onClick = { isSprinting = !isSprinting },
                                modifier = Modifier
                                    .size(50.dp)
                                    .background(
                                        if (isSprinting) Color(0xFF2E7D32).copy(alpha = 0.85f) else Color.Black.copy(alpha = 0.5f),
                                        CircleShape
                                    )
                                    .border(
                                        1.dp,
                                        if (isSprinting) Color(0xFF4CAF50) else Color.White.copy(alpha = 0.25f),
                                        CircleShape
                                    )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DirectionsRun,
                                    contentDescription = "Sprint speed modifier",
                                    tint = if (isSprinting) Color.White else Color(0xFFC4BDB1)
                                )
                            }

                            // Drinking Almond water
                            val hasAlmond = engine.almondWaterCount > 0
                            IconButton(
                                onClick = {
                                    if (hasAlmond) {
                                        engine.drinkAlmondWater()
                                    }
                                },
                                modifier = Modifier
                                    .size(50.dp)
                                    .background(
                                        if (hasAlmond) Color(0xFF197386).copy(alpha = 0.85f) else Color.Black.copy(alpha = 0.5f),
                                        CircleShape
                                    )
                                    .border(
                                        1.dp,
                                        if (hasAlmond) Color(0xFF3EE2DF) else Color.White.copy(alpha = 0.25f),
                                        CircleShape
                                    )
                            ) {
                                @OptIn(ExperimentalMaterial3Api::class)
                                BadgedBox(
                                    badge = {
                                        if (engine.almondWaterCount > 0) {
                                            Badge(
                                                containerColor = Color(0xFF3EE2DF),
                                                contentColor = Color.Black
                                            ) {
                                                Text(
                                                    text = engine.almondWaterCount.toString(),
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocalDrink,
                                        contentDescription = "Drink Almond restorative potion",
                                        tint = if (hasAlmond) Color.White else Color(0xFFC4BDB1)
                                    )
                                }
                            }

                            // Exit to menu hatch latch
                            IconButton(
                                onClick = { onExitToMenu() },
                                modifier = Modifier
                                    .size(50.dp)
                                    .background(Color(0xFF3D1616).copy(alpha = 0.75f), CircleShape)
                                    .border(1.dp, Color(0xFFCC5555), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Cancel,
                                    contentDescription = "Abort run log",
                                    tint = Color(0xFFFF8E8E)
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- GAME OVER SCREEN LAYOUT ---
        if (engine.state == GameState.GAMEOVER) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F0707)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(Color(0xFF3D1515), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Fatal error",
                            tint = Color(0xFFE57373),
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "SYS_RECON_LOST: SANITY DEPLETED",
                        color = Color(0xFFE57373),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Visual feeds went static. Subject permanently lost inside Level ${engine.currentLevelIndex} maze records.",
                        color = Color(0xFFB1A5A5),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.widthIn(max = 450.dp)
                    ) {
                        Button(
                            onClick = {
                                // Retry level
                                engine.startLevel(
                                    levelIndex = engine.currentLevelIndex,
                                    difficulty = saveManager.getDifficulty(),
                                    sensitivity = saveManager.getSensitivity()
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFC62828),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "REBOOT TRANSITION",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                engine.state = GameState.MENU
                                onExitToMenu()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .border(1.dp, Color(0xFF553D3D), RoundedCornerShape(6.dp)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFD32F2F)
                            ),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "TERMINATE LOSS DATA",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // --- VICTORY OVERLAY SCREEN LAYOUT ---
        if (engine.state == GameState.VICTORY) {
            // Unlock next level immediately in Saves
            LaunchedEffect(Unit) {
                val nextLvl = engine.currentLevelIndex + 1
                if (nextLvl < GameLevels.levels.size) {
                    saveManager.unlockLevel(nextLvl)
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F1410)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(Color(0xFF1B5E20), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = Color(0xFFA5D6A7),
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "LOG_RECORDED: ESCAPE ROUTE SECURED",
                        color = Color(0xFF81C784),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Subject navigated anomalous door out of ${engine.currentLevelData.name} record blocks.",
                        color = Color(0xFFAAB8AB),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    val isLastLevel = engine.currentLevelIndex >= GameLevels.levels.size - 1

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.widthIn(max = 480.dp)
                    ) {
                        Button(
                            onClick = {
                                if (!isLastLevel) {
                                    engine.startLevel(
                                        levelIndex = engine.currentLevelIndex + 1,
                                        difficulty = saveManager.getDifficulty(),
                                        sensitivity = saveManager.getSensitivity()
                                    )
                                } else {
                                    engine.state = GameState.MENU
                                    onExitToMenu()
                                }
                            },
                            modifier = Modifier
                                .weight(1.2f)
                                .height(46.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2E7D32),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (isLastLevel) "DISCHARGE TAPE" else "CORRELATE NEXT LOBBY",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                engine.state = GameState.MENU
                                onExitToMenu()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .border(1.dp, Color(0xFF38553B), RoundedCornerShape(6.dp)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFF81C784)
                            ),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "TO CHRONICLES",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

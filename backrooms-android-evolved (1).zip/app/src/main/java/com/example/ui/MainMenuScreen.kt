package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameSaveManager
import com.example.game.GameLevels
import kotlinx.coroutines.delay

enum class MenuPanel {
    MAIN,
    SAVES,
    SETTINGS,
    CREDITS,
    FEEDBACK
}

@Composable
fun MainMenuScreen(
    saveManager: GameSaveManager,
    onStartGame: (levelIndex: Int, difficulty: Int, sensitivity: Float) -> Unit
) {
    val context = LocalContext.current
    var currentPanel by remember { mutableStateOf(MenuPanel.MAIN) }

    // Saved values and states
    val maxUnlockedLevel by remember { mutableStateOf(saveManager.getMaxUnlockedLevel()) }
    var difficultyIndex by remember { mutableStateOf(saveManager.getDifficulty()) } 
    var sensitivity by remember { mutableStateOf(saveManager.getSensitivity()) }
    var soundEnabled by remember { mutableStateOf(saveManager.isSoundEnabled()) }

    // Volume states
    var masterVolume by remember { mutableStateOf(0.85f) }
    var musicVolume by remember { mutableStateOf(0.60f) }
    var sfxVolume by remember { mutableStateOf(0.70f) }
    var brightnessSetting by remember { mutableStateOf(1.0f) }
    var graphicsQuality by remember { mutableStateOf(2) } // 0=Low, 1=Medium, 2=High

    // Feedback states
    var feedbackText by remember { mutableStateOf("") }
    var emailText by remember { mutableStateOf("") }
    var issueType by remember { mutableStateOf("SELECT AN ISSUE TYPE...") }
    var showDropdownMenu by remember { mutableStateOf(false) }
    var simulatedTransmissionState by remember { mutableStateOf("") }

    // Glitch title effects
    val infiniteTransition = rememberInfiniteTransition(label = "LiminalTitleGlow")
    val titleGlitchOffset by infiniteTransition.animateFloat(
        initialValue = -0.8f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(250, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glitch"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070705))
    ) {
        // atmospheric Backrooms high-fidelity landscape environment wallpaper
        Image(
            painter = painterResource(id = R.drawable.img_backrooms_bg),
            contentDescription = "Liminal chamber landscape backdrop",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Overlay a very eerie warm yellow grading vignette and custom low-contrast dark scanlines
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Warm golden vignette
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x3B352E10),
                        Color(0xAA020201)
                    ),
                    center = Offset(width / 2f, height / 2f),
                    radius = width * 0.75f
                )
            )

            // Dynamic surveillance CRT scanning lines
            val lineGap = 12f
            var trackingY = 0f
            while (trackingY < height) {
                drawLine(
                    color = Color(0xFF6B5824).copy(alpha = 0.05f),
                    start = Offset(0f, trackingY),
                    end = Offset(width, trackingY),
                    strokeWidth = 1f
                )
                trackingY += lineGap
            }
        }

        // Split menu elements inside standard insets
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 48.dp, vertical = 24.dp)
        ) {
            // Eerie Glitch title header showing at the top center of all panels
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(contentAlignment = Alignment.Center) {
                    // Underlay Red Glitch Text
                    Text(
                        text = "DESOLATION:",
                        color = Color(0xFFAA2211),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 6.sp,
                        modifier = Modifier.offset(x = (titleGlitchOffset * 2.5f).dp, y = (titleGlitchOffset * 0.5f).dp)
                    )
                    // Main Title text
                    Text(
                        text = "DESOLATION:",
                        color = Color(0xFFE5B842).copy(alpha = glowAlpha),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 6.sp
                    )
                }

                Text(
                    text = "THE BACKROOMS",
                    color = Color(0xFFE5B842).copy(alpha = 0.75f),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 8.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )

                // Subtitle panel marker
                Text(
                    text = when (currentPanel) {
                        MenuPanel.MAIN -> ""
                        MenuPanel.SAVES -> "SAVES"
                        MenuPanel.SETTINGS -> "SETTINGS"
                        MenuPanel.CREDITS -> "CREDITS"
                        MenuPanel.FEEDBACK -> "FEEDBACK"
                    },
                    color = Color(0xFFFFE082),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 5.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // --- ANIMATED VISIBILITY LAYER FOR PANELS ---

            // Panel 1: MAIN LANDING SCREEN
            AnimatedVisibility(
                visible = currentPanel == MenuPanel.MAIN,
                enter = fadeIn(animationSpec = tween(400)),
                exit = fadeOut(animationSpec = tween(300)),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Left Column Menu options
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 12.dp, top = 40.dp),
                        verticalArrangement = Arrangement.spacedBy(22.dp)
                    ) {
                        GlowingMenuOption(
                            text = "PLAY",
                            onClick = { currentPanel = MenuPanel.SAVES },
                            alignLeft = true
                        )
                        GlowingMenuOption(
                            text = "SETTINGS",
                            onClick = { currentPanel = MenuPanel.SETTINGS },
                            alignLeft = true
                        )
                        GlowingMenuOption(
                            text = "CREDITS",
                            onClick = { currentPanel = MenuPanel.CREDITS },
                            alignLeft = true
                        )
                    }

                    // Bottom Right Menu options
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 12.dp, bottom = 12.dp)
                    ) {
                        GlowingMenuOption(
                            text = "FEEDBACK",
                            onClick = { currentPanel = MenuPanel.FEEDBACK },
                            alignLeft = false
                        )
                    }
                }
            }

            // Panel 2: SAVES SCREEN
            AnimatedVisibility(
                visible = currentPanel == MenuPanel.SAVES,
                enter = fadeIn(animationSpec = tween(400)),
                exit = fadeOut(animationSpec = tween(300)),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 90.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Horizontal Saves slot row
                    Row(
                        modifier = Modifier
                            .padding(top = 12.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // SAVE Slot 1 (Level 0)
                        SaveSlotCard(
                            slotName = "SAVE 1",
                            levelName = "Backrooms\nLevel 1",
                            isUnlocked = true,
                            onClick = { onStartGame(0, difficultyIndex, sensitivity) }
                        )

                        // SAVE Slot 2 (Level 1)
                        SaveSlotCard(
                            slotName = "SAVE 2",
                            levelName = "Backrooms\nLevel 2",
                            isUnlocked = maxUnlockedLevel >= 1,
                            onClick = { onStartGame(1, difficultyIndex, sensitivity) }
                        )

                        // SAVE Slot 3 (Level 2)
                        SaveSlotCard(
                            slotName = "SAVE 3",
                            levelName = "Backrooms\nLevel 3",
                            isUnlocked = maxUnlockedLevel >= 2,
                            onClick = { onStartGame(2, difficultyIndex, sensitivity) }
                        )
                    }

                    // Back button centered at the bottom
                    ThinGlossButton(
                        text = "BACK",
                        onClick = { currentPanel = MenuPanel.MAIN }
                    )
                }
            }

            // Panel 3: SETTINGS SCREEN
            AnimatedVisibility(
                visible = currentPanel == MenuPanel.SETTINGS,
                enter = fadeIn(animationSpec = tween(400)),
                exit = fadeOut(animationSpec = tween(300)),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 95.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Settings box container supporting scroll
                    Column(
                        modifier = Modifier
                            .widthIn(max = 620.dp)
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Master volume
                        RetroSliderSettingRow(
                            label = "MASTER VOLUME",
                            value = masterVolume,
                            onValueChange = { masterVolume = it }
                        )

                        // Music volume
                        RetroSliderSettingRow(
                            label = "MUSIC VOLUME",
                            value = musicVolume,
                            onValueChange = { musicVolume = it }
                        )

                        // SFX volume
                        RetroSliderSettingRow(
                            label = "SFX VOLUME",
                            value = sfxVolume,
                            onValueChange = { sfxVolume = it }
                        )

                        // Brightness helper slider
                        RetroSliderSettingRow(
                            label = "BRIGHTNESS",
                            value = brightnessSetting,
                            onValueChange = { brightnessSetting = it }
                        )

                        // Look sensitivity slider
                        RetroSliderSettingRow(
                            label = "SENSITIVITY",
                            value = sensitivity,
                            valueRange = 0.5f..2.5f,
                            onValueChange = {
                                sensitivity = it
                                saveManager.setSensitivity(it)
                            }
                        )

                        // Graphics switcher box
                        SettingCapsuleBox(label = "GRAPHICS") {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("LOW", "MEDIUM", "HIGH").forEachIndexed { index, title ->
                                    val isSelected = graphicsQuality == index
                                    Box(
                                        modifier = Modifier
                                            .border(
                                                width = 1.dp,
                                                color = if (isSelected) Color(0xFFFFF092) else Color(0x33E5B842),
                                                shape = RoundedCornerShape(4.dp)
                                            )
                                            .background(
                                                color = if (isSelected) Color(0x3BE5B842) else Color.Transparent
                                            )
                                            .clickable { graphicsQuality = index }
                                            .padding(horizontal = 10.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = title,
                                            color = if (isSelected) Color(0xFFFFF092) else Color(0xFFE5B842).copy(alpha = 0.5f),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Bottom back button
                    ThinGlossButton(
                        text = "BACK",
                        onClick = { currentPanel = MenuPanel.MAIN },
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }

            // Panel 4: CREDITS SCREEN
            AnimatedVisibility(
                visible = currentPanel == MenuPanel.CREDITS,
                enter = fadeIn(animationSpec = tween(400)),
                exit = fadeOut(animationSpec = tween(300)),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 100.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Credits container box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .widthIn(max = 520.dp)
                            .border(1.dp, Color(0xFFE5B842).copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .background(Color(0xCC090906))
                            .padding(24.dp)
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CreditItemRow(roleName = "GAME DESIGN", assigneeName = "SOLO DEVELOPER")
                            CreditItemRow(roleName = "PROGRAMMING", assigneeName = "SOLO DEVELOPER")
                            CreditItemRow(roleName = "UI DESIGN", assigneeName = "SOLO DEVELOPER")
                            CreditItemRow(roleName = "ENVIRONMENT ART", assigneeName = "SOLO DEVELOPER")
                            CreditItemRow(roleName = "SOUND DESIGN", assigneeName = "SOLO DEVELOPER")
                            CreditItemRow(roleName = "SPECIAL THANKS", assigneeName = "THE PLAYERS")
                        }
                    }

                    // Back button centered
                    ThinGlossButton(
                        text = "BACK",
                        onClick = { currentPanel = MenuPanel.MAIN }
                    )
                }
            }

            // Panel 5: FEEDBACK SCREEN
            AnimatedVisibility(
                visible = currentPanel == MenuPanel.FEEDBACK,
                enter = fadeIn(animationSpec = tween(400)),
                exit = fadeOut(animationSpec = tween(300)),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 95.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Feedback parameters column
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .widthIn(max = 520.dp)
                            .border(1.dp, Color(0xFFE5B842).copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .background(Color(0xCC090906))
                            .padding(horizontal = 24.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Textbox Your Feedback
                        Column {
                            Text(
                                text = "YOUR FEEDBACK",
                                color = Color(0xFFE5B842),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .border(1.dp, Color(0x4DE5B842), RoundedCornerShape(6.dp))
                                    .background(Color(0xE6060604))
                                    .padding(10.dp)
                            ) {
                                if (feedbackText.isEmpty()) {
                                    Text(
                                        text = "WRITE YOUR FEEDBACK HERE...",
                                        color = Color(0x66E5B842),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                BasicTextField(
                                    value = feedbackText,
                                    onValueChange = { feedbackText = it },
                                    textStyle = TextStyle(
                                        color = Color(0xFFFFF092),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    ),
                                    modifier = Modifier.fillMaxSize(),
                                    cursorBrush = SolidColor(Color(0xFFFFD54F))
                                )
                            }
                        }

                        // 2. Email field
                        Column {
                            Text(
                                text = "EMAIL (OPTIONAL)",
                                color = Color(0xFFE5B842),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(38.dp)
                                    .border(1.dp, Color(0x4DE5B842), RoundedCornerShape(6.dp))
                                    .background(Color(0xE6060604))
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                if (emailText.isEmpty()) {
                                    Text(
                                        text = "ENTER YOUR EMAIL...",
                                        color = Color(0x66E5B842),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                BasicTextField(
                                    value = emailText,
                                    onValueChange = { emailText = it },
                                    singleLine = true,
                                    textStyle = TextStyle(
                                        color = Color(0xFFFFF092),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    ),
                                    modifier = Modifier.fillMaxSize(),
                                    cursorBrush = SolidColor(Color(0xFFFFD54F))
                                )
                            }
                        }

                        // 3. Dropdown selector field
                        Column {
                            Text(
                                text = "ISSUE TYPE",
                                color = Color(0xFFE5B842),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(38.dp)
                                    .border(1.dp, Color(0x4DE5B842), RoundedCornerShape(6.dp))
                                    .background(Color(0xE6060604))
                                    .clickable { showDropdownMenu = !showDropdownMenu }
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = issueType,
                                        color = if (issueType.startsWith("SELECT")) Color(0x66E5B842) else Color(0xFFFFF092),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Issue type filter arrows",
                                        tint = Color(0xFFE5B842),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                DropdownMenu(
                                    expanded = showDropdownMenu,
                                    onDismissRequest = { showDropdownMenu = false },
                                    modifier = Modifier.background(Color(0xFF0C0B08)).border(1.dp, Color(0xFFE5B842))
                                ) {
                                    listOf("BUG", "SUGGESTION", "COMPLAINT", "OTHER").forEach { type ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = type,
                                                    color = Color(0xFFFFD54F),
                                                    fontFamily = FontFamily.Monospace,
                                                    fontSize = 11.sp
                                                )
                                            },
                                            onClick = {
                                                issueType = type
                                                showDropdownMenu = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Alert simulated telemetry transmission readout if feedback triggered
                        if (simulatedTransmissionState.isNotEmpty()) {
                            Text(
                                text = simulatedTransmissionState,
                                color = Color(0xFF81C784),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp)
                            )
                        }
                    }

                    // Double action buttons row
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ThinGlossButton(
                            text = "SEND",
                            onClick = {
                                if (feedbackText.trim().isNotEmpty()) {
                                    simulatedTransmissionState = "📡 CONNECTING TO ANALOG SUITE... SUBMITTED!"
                                    feedbackText = ""
                                    emailText = ""
                                    issueType = "SELECT AN ISSUE TYPE..."
                                } else {
                                    simulatedTransmissionState = "⚠️ RECORD CORRUPTED: TEXT BODY CANNOT BE EMPTY"
                                }
                            }
                        )
                        ThinGlossButton(
                            text = "BACK",
                            onClick = { 
                                simulatedTransmissionState = ""
                                currentPanel = MenuPanel.MAIN 
                            }
                        )
                    }
                }
            }
        }
    }
}

// Custom underlined menu options with glowing yellow circle caps at custom alignment boundaries
@Composable
fun GlowingMenuOption(
    text: String,
    onClick: () -> Unit,
    alignLeft: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "GlLineScale")
    val dotPulse by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dotPulse"
    )

    Column(
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = LocalIndication.current,
                onClick = onClick
            )
            .padding(bottom = 4.dp)
            .width(IntrinsicSize.Max)
    ) {
        Text(
            text = text,
            color = Color(0xFFE5B842),
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 3.sp,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Draw custom underline with elegant terminal circuit ball
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
        ) {
            val elementW = size.width
            val baseLineOffset = 1.5f
            val nodeRadius = 5f

            // Underline extends slightly beyond text block
            val startX = if (alignLeft) 0f else -30f
            val endX = if (alignLeft) elementW + 30f else elementW

            drawLine(
                color = Color(0xFFE5B842).copy(alpha = 0.75f),
                start = Offset(startX, baseLineOffset),
                end = Offset(endX, baseLineOffset),
                strokeWidth = 2.5f
            )

            // Draw glowing terminal node dot on extended side
            val dotCenter = if (alignLeft) endX else startX
            drawCircle(
                color = Color(0xFFFFF7C2),
                radius = nodeRadius,
                center = Offset(dotCenter, baseLineOffset)
            )

            // Pulse glowing ring around
            drawCircle(
                color = Color(0xFFFFD34F).copy(alpha = 0.35f * dotPulse),
                radius = nodeRadius * 2.8f,
                center = Offset(dotCenter, baseLineOffset)
            )
        }
    }
}

// Saves Panel level selection folders matching the layout of the Save card design from the screenshots exactly!
@Composable
fun SaveSlotCard(
    slotName: String,
    levelName: String,
    isUnlocked: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(190.dp)
            .height(245.dp)
            .border(
                width = 1.dp,
                color = if (isUnlocked) Color(0xFFE5B842).copy(alpha = 0.6f) else Color(0x33E5B842),
                shape = RoundedCornerShape(10.dp)
            )
            .clip(RoundedCornerShape(10.dp))
            .clickable(enabled = isUnlocked, onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xD90A0905)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = slotName,
                    color = if (isUnlocked) Color(0xFFFFF092) else Color(0xFFE5B842).copy(alpha = 0.35f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )

                // Divider line underneath slot label
                Box(
                    modifier = Modifier
                        .padding(top = 4.dp, bottom = 8.dp)
                        .fillMaxWidth(0.6f)
                        .height(1.dp)
                        .background(Color(0xFFE5B842).copy(alpha = 0.3f))
                )

                Text(
                    text = levelName,
                    color = if (isUnlocked) Color(0xFFE5B842) else Color(0xFFE5B842).copy(alpha = 0.35f),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    lineHeight = 13.sp
                )
            }

            // Thumbnail preview block displaying the atmosphere
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .border(1.dp, Color(0x33E5B842), RoundedCornerShape(6.dp))
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (isUnlocked) {
                    // Display cropped overlay scan screenshot inside Save Card
                    Image(
                        painter = painterResource(id = R.drawable.img_backrooms_bg),
                        contentDescription = "Save state level screen screenshot snapshot",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = 0.7f
                    )

                    // Overlay simulated camera elements info of surveillance
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(6.dp)
                    ) {
                        Text(
                            text = "CAM_S${slotName.last()}",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 7.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.align(Alignment.TopStart)
                        )
                        Text(
                            text = "PLAY",
                            color = Color.Green.copy(alpha = 0.61f),
                            fontSize = 7.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.align(Alignment.TopEnd)
                        )
                    }
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "🔒 Level lock sign indicator",
                            tint = Color(0x4DE5B842),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "LOCKED",
                            color = Color(0x4DE5B842),
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// Classic double column row elements connected by elegant horizontal cords
@Composable
fun CreditItemRow(roleName: String, assigneeName: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = roleName,
            color = Color(0xFFE5B842),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Start
        )

        // Branching connector line meeting in center orb glow
        Row(
            modifier = Modifier.weight(1.1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .weight(1.0f)
                    .height(1.dp)
                    .background(Color(0xFFE5B842).copy(alpha = 0.25f))
            )
            // Central solar golden node dot
            Box(
                modifier = Modifier
                    .padding(horizontal = 6.dp)
                    .size(5.dp)
                    .background(Color(0xFFFFF7C2), CircleShape)
            )
            Box(
                modifier = Modifier
                    .weight(1.0f)
                    .height(1.dp)
                    .background(Color(0xFFE5B842).copy(alpha = 0.25f))
            )
        }

        Text(
            text = assigneeName,
            color = Color(0xFFE5B842),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.End
        )
    }
}

// Capsules for enclosing setting volume knobs and parameters
@Composable
fun SettingCapsuleBox(
    label: String,
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .border(1.dp, Color(0xFFE5B842).copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .background(Color(0xE6080805))
            .padding(horizontal = 14.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = Color(0xFFE5B842),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

// Custom elegant slider setting inside capsule box
@Composable
fun RetroSliderSettingRow(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float> = 0.0f..1.0f,
    onValueChange: (Float) -> Unit
) {
    SettingCapsuleBox(label = label) {
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFFFFF092),
                activeTrackColor = Color(0xFFE5B842),
                inactiveTrackColor = Color(0x33E5B842)
            ),
            modifier = Modifier
                .width(220.dp)
                .fillMaxHeight()
        )
    }
}

// Outlined rectangular glow button matching the "BACK" and "SEND" designs exactly!
@Composable
fun ThinGlossButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .border(1.dp, Color(0xFFE5B842), RoundedCornerShape(6.dp))
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0x99000000))
            .clickable(onClick = onClick)
            .width(135.dp)
            .height(35.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color(0xFFE5B842),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 2.sp
        )
    }
}
